package Frames;

public class ViewInformation {
	String num,name,intro;
	public  ViewInformation(){
		super();
	}
	public  ViewInformation(String num,String name,String intro){
		this.num=num;
		this.name=name;
		this.intro=intro;
	}
	public String getNum(){
		return num;
	}
	public String getName(){
		return name;
	}
	public String getIntro(){
		return intro;
	}
}
