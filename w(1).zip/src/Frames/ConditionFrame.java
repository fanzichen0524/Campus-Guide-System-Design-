package Frames;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ConditionFrame extends JFrame implements ActionListener{
	JLabel label=new JLabel();
	JButton btn1,btn2,btn3,btn4,btn5;
	JPanel pl1;
	JTextArea route;
	String string="";
	public ConditionFrame() {
		ImageIcon icon = new ImageIcon("src/image/3.jpg");
		label.setIcon(icon);
		label.setBounds(0,0, 600, 400);
		add(label);
		btn1=new JButton("���е���·");
		btn2=new JButton("���е���·");
		btn3=new JButton("һ���羰��");
		btn4=new JButton("�����羰��");
		btn5=new JButton("�����羰��");
		route=new JTextArea(5,50);
		pl1=new JPanel(new FlowLayout(FlowLayout.CENTER,10,20));
		pl1.add(btn1);
		pl1.add(btn2);
		pl1.add(btn3);
		pl1.add(btn4);
		pl1.add(btn5);
		pl1.add(new JScrollPane(route));
		pl1.setBounds(0, 400, 600, 400);
		add(pl1);
		btn1.addActionListener(this);
		btn2.addActionListener(this);
		btn3.addActionListener(this);
		btn4.addActionListener(this);
		btn5.addActionListener(this);
		setBounds(600,300,600,630);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); 
		setLocation((screenSize.width-getWidth())/2, (screenSize.height-getHeight())/2);
		setLayout(null);
		setTitle("У԰ȫ��ͼ");
		setVisible(false);
		validate();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource()==btn1) {
			string="";
			for(int i=0;i<26;i++){
				if(Util.list1.get(i).getType()=="���е�"){
					string+=Util.list1.get(i).getName().toString()+"  ";
				}
			}
			route.setText(string);
		}
		
		if (e.getSource()==btn2) {
			string="";
			for(int i=0;i<26;i++){
				if(Util.list1.get(i).getType()=="���е�"){
					string+=Util.list1.get(i).getName().toString()+"  ";
				}
			}
			route.setText(string);
		}
		
		if (e.getSource()==btn3) {
			string="";
			for(int i=0;i<26;i++){
				if(Util.list1.get(i).getLevel()=="һ���羰��"){
					string+=Util.list1.get(i).getName().toString()+"  ";
				}
			}
			route.setText(string);
		}
		
		if (e.getSource()==btn4) {
			string="";
			for(int i=0;i<26;i++){
				if(Util.list1.get(i).getLevel()=="�����羰��"){
					string+=Util.list1.get(i).getName().toString()+"  ";
				}
			}
			route.setText(string);
		}
		
		if (e.getSource()==btn5) {
			string="";
			for(int i=0;i<26;i++){
				if(Util.list1.get(i).getLevel()=="�����羰��"){
					string+=Util.list1.get(i).getName().toString()+"  ";
				}
			}
			route.setText(string);
		}
		
	}
}
