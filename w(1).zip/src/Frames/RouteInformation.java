package Frames;

public class RouteInformation {
	String name,type,level;
	int longs;
	public  RouteInformation(){
		super();
	}
	public  RouteInformation(String name,String type,String level,int longs){
		this.name=name;
		this.type=type;
		this.level=level;
		this.longs=longs;
	}
	public String getName(){
		return name;
	}
	public String getType(){
		return type;
	}
	public String getLevel(){
		return level;
	}
	public int getLongs(){
		return longs;
	}
}
