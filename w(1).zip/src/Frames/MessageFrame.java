package Frames;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;



public class MessageFrame extends JFrame implements ActionListener {
	JLabel label=new JLabel();
	JPanel pl1;
	JButton btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn10,btn,btn11,btn12,btn13,btn14,btn15;
	JLabel la1,la2,la3;
	JTextField num,name;
	JTextArea intro;
		public MessageFrame() {
			ImageIcon icon = new ImageIcon("src/image/2.jpg");
			label.setIcon(icon);
			label.setBounds(0,0, 600, 400);
			
			btn1=new JButton("һ��");
			btn2=new JButton("����");
			btn3=new JButton("����");
			btn4=new JButton("����¥");
			btn5=new JButton("����¥");
			btn6=new JButton("��ͼ");
			btn7=new JButton("��ͼ");
			btn8=new JButton("��ѧԺ");
			btn9=new JButton("�ŵ�ѧԺ");
			btn10=new JButton("����ѧԺ");
			btn=new JButton("ʳƷѧԺ");
			btn11=new JButton("��������");
			btn12=new JButton("������");
			btn13=new JButton("��ѧԺ");
			btn14=new JButton("��¥");
			btn11.setBounds(70, 330, 100, 30);
			btn12.setBounds(470, 330, 80, 30);
			btn13.setBounds(70, 250, 80, 30);
			btn14.setBounds(470, 250, 80, 30);
			btn11.setBackground(new Color(192,192,192));
			btn12.setBackground(new Color(192,192,192));
			btn13.setBackground(new Color(192,192,192));
			btn14.setBackground(new Color(192,192,192));
			
			btn1.setBounds(270, 190, 60, 30);
			btn2.setBounds(70, 90, 80, 30);
			btn3.setBounds(170, 90, 80, 30);
			btn4.setBounds(270, 90, 80, 30);
			btn5.setBounds(365, 90, 90, 30);
			btn6.setBounds(470, 90, 80, 30);
			btn7.setBounds(70, 190, 80, 30);
			btn8.setBounds(470, 190, 80, 30);
			btn9.setBounds(160, 270, 100, 30);
			btn.setBounds(360, 280, 100, 30);
			btn10.setBounds(260, 330, 100, 30);
			btn1.setBackground(new Color(192,192,192));
			btn2.setBackground(new Color(240,255,255));
			btn3.setBackground(new Color(255,235,205));
			btn4.setBackground(new Color(240,255,240));
			btn5.setBackground(new Color(176,224,230));
			btn6.setBackground(new Color(250,235,215));
			btn7.setBackground(new Color(0,255,255));
			btn8.setBackground(new Color(245,245,245));
			btn9.setBackground(new Color(255,227,132));
			btn10.setBackground(new Color(210,180,140));
			btn.setBackground(new Color(189,252,201));
			add(btn1);
			add(btn2);
			add(btn3);
			add(btn4);
			add(btn5);
			add(btn6);
			add(btn7);
			add(btn8);
			add(btn9);
			add(btn10);
			add(btn);
			add(btn11);
			add(btn12);
			add(btn13);
			add(btn14);
			add(label);
			btn1.addActionListener(this);
			btn2.addActionListener(this);
			btn3.addActionListener(this);
			btn4.addActionListener(this);
			btn5.addActionListener(this);
			btn6.addActionListener(this);
			btn7.addActionListener(this);
			btn8.addActionListener(this);
			btn9.addActionListener(this);
			btn10.addActionListener(this);
			btn.addActionListener(this);
			btn11.addActionListener(this);
			btn12.addActionListener(this);
			btn13.addActionListener(this);
			btn14.addActionListener(this);
			la1=new JLabel("��ţ�");
			la2=new JLabel("���ƣ�");
			la3=new JLabel("�����飺");
			num=new JTextField(15);
			name=new JTextField(15);
			intro=new JTextArea(5,50);
			pl1=new JPanel(new FlowLayout(FlowLayout.CENTER,30,20));
			pl1.add(la1);
			pl1.add(num);
			pl1.add(la2);
			pl1.add(name);
			pl1.add(la3);
			pl1.add(new JScrollPane(intro));
			pl1.setBounds(0, 400, 600, 400);
			add(pl1);
			setBounds(600,300,600,630);
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); 
			setLocation((screenSize.width-getWidth())/2, (screenSize.height-getHeight())/2);
			setLayout(null);
			setTitle("У԰ȫ��ͼ");
			setVisible(false);
			validate();
		}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==btn1) {
			num.setText(Util.list.get(0).getNum());
			name.setText(Util.list.get(0).getName());
			intro.setText(Util.list.get(0).getIntro());
		}
		if (e.getSource()==btn2) {
			num.setText(Util.list.get(1).getNum());
			name.setText(Util.list.get(1).getName());
			intro.setText(Util.list.get(1).getIntro());
		}
		if (e.getSource()==btn3) {
			num.setText(Util.list.get(2).getNum());
			name.setText(Util.list.get(2).getName());
			intro.setText(Util.list.get(2).getIntro());
		}
		if (e.getSource()==btn4) {
			num.setText(Util.list.get(3).getNum());
			name.setText(Util.list.get(3).getName());
			intro.setText(Util.list.get(3).getIntro());
		}
		if (e.getSource()==btn5) {
			num.setText(Util.list.get(4).getNum());
			name.setText(Util.list.get(4).getName());
			intro.setText(Util.list.get(4).getIntro());
		}
		if (e.getSource()==btn6) {
			num.setText(Util.list.get(5).getNum());
			name.setText(Util.list.get(5).getName());
			intro.setText(Util.list.get(5).getIntro());
		}
		if (e.getSource()==btn7) {
			num.setText(Util.list.get(6).getNum());
			name.setText(Util.list.get(6).getName());
			intro.setText(Util.list.get(6).getIntro());
		}
		if (e.getSource()==btn8) {
			num.setText(Util.list.get(7).getNum());
			name.setText(Util.list.get(7).getName());
			intro.setText(Util.list.get(7).getIntro());
		}
		if (e.getSource()==btn9) {
			num.setText(Util.list.get(8).getNum());
			name.setText(Util.list.get(8).getName());
			intro.setText(Util.list.get(8).getIntro());
		}
		if (e.getSource()==btn10) {
			num.setText(Util.list.get(9).getNum());
			name.setText(Util.list.get(9).getName());
			intro.setText(Util.list.get(9).getIntro());
		}
		if (e.getSource()==btn) {
			num.setText(Util.list.get(10).getNum());
			name.setText(Util.list.get(10).getName());
			intro.setText(Util.list.get(10).getIntro());
		}
		
		if (e.getSource()==btn11) {
			num.setText(Util.list.get(11).getNum());
			name.setText(Util.list.get(11).getName());
			intro.setText(Util.list.get(11).getIntro());
		}
		if (e.getSource()==btn12) {
			num.setText(Util.list.get(12).getNum());
			name.setText(Util.list.get(12).getName());
			intro.setText(Util.list.get(12).getIntro());
		}
		if (e.getSource()==btn13) {
			num.setText(Util.list.get(13).getNum());
			name.setText(Util.list.get(13).getName());
			intro.setText(Util.list.get(13).getIntro());
		}
		if (e.getSource()==btn14) {
			num.setText(Util.list.get(14).getNum());
			name.setText(Util.list.get(14).getName());
			intro.setText(Util.list.get(14).getIntro());
		}
		
	}

	
}