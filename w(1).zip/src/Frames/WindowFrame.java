package Frames;


import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;


public class WindowFrame {
	public static void main(String args[]){
		new Win();
	}
}
	

class Win extends JFrame implements ActionListener{
	JLabel label=new JLabel();
	JPanel pl1;
	JMenu menu1,menu2;
	JMenuItem item1=new JMenuItem("���ȫУ����");
	JMenuItem item2=new JMenuItem("����������Ŀ�ĵ�");
	JMenuItem item3=new JMenuItem("������ѯ·��");
	JMenuBar bar=new JMenuBar();
		Win(){
			pl1=new JPanel();
			setJMenuBar(bar);
			ImageIcon icon = new ImageIcon("src/image/1.jpg");
			label.setIcon(icon);
			label.setBounds(0,0, 600, 450);
			pl1.add(label);
			add(pl1);
			setBounds(600,300,900,550);
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); 
			
			setLocation((screenSize.width-getWidth())/2, (screenSize.height-getHeight())/2);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			menu1=new JMenu("������Ϣ");
			menu2=new JMenu("��ѯ·��");
			menu1.add(item1);
			menu2.add(item2);
			menu2.add(item3);
			bar.add(menu1);
			bar.add(menu2);
			item1.addActionListener(this);
			item2.addActionListener(this);
			item3.addActionListener(this);
			setTitle("У԰��ѯ����ϵͳ");
			setVisible(true);
			validate();
			
		}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==item1){
		MessageFrame message=new MessageFrame();
			message.setVisible(true);
		}
		if (e.getSource()==item2) {
			RouteFrame route=new RouteFrame();
			route.setVisible(true);
		}
		if (e.getSource()==item3) {
			ConditionFrame condition=new ConditionFrame();
			condition.setVisible(true);
		}
		
	}
}

