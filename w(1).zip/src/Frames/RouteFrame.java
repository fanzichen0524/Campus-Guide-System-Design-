package Frames;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Graph.MatrixGraph;
import Graph.Triple;


public class RouteFrame extends JFrame implements ActionListener,ItemListener{
	JLabel label1,label2,label3;
	JButton btn;
	JComboBox<String> box1,box2;
	JTextArea route;
	JPanel pl1;
	String start,end;
	private int a,b;
	
		public RouteFrame(){
			label1=new JLabel("��ѡ������㣺");
			label2=new JLabel("��ѡ��Ŀ�ĵأ�");
			btn=new JButton("��ѯ��ϸ·��");
			box1=new JComboBox<String>();
			box1.addItem("  ");
			box1.addItem("һ��");
			box1.addItem("����");
			box1.addItem("����");
			box1.addItem("����¥");
			box1.addItem("����¥");
			box1.addItem("��ͼ");
			box1.addItem("��ͼ");
			box1.addItem("��ѧԺ");
			box1.addItem("�ŵ�ѧԺ");
			box1.addItem("����ѧԺ");
			box1.addItem("ʳƷѧԺ");
			box1.addItem("��������");
			box1.addItem("������");
			box1.addItem("��ѧԺ");
			box1.addItem("��¥");
			box2=new JComboBox<String>();
			box2.addItem("  ");
			box2.addItem("һ��");
			box2.addItem("����");
			box2.addItem("����");
			box2.addItem("����¥");
			box2.addItem("����¥");
			box2.addItem("��ͼ");
			box2.addItem("��ͼ");
			box2.addItem("��ѧԺ");
			box2.addItem("�ŵ�ѧԺ");
			box2.addItem("����ѧԺ");
			box2.addItem("ʳƷѧԺ");
			box2.addItem("��������");
			box2.addItem("������");
			box2.addItem("��ѧԺ");
			box2.addItem("��¥");
			route=new JTextArea(5,40);
			pl1=new JPanel(new FlowLayout(FlowLayout.CENTER,30,20));
			pl1.add(label1);
			pl1.add(box1);
			pl1.add(label2);
			pl1.add(box2);
			pl1.add(btn);
			pl1.add(new JScrollPane(route));
			pl1.setBounds(0, 0, 500, 400);
			box1.addItemListener(this);
			box2.addItemListener(this);
			btn.addActionListener(this);
			add(pl1);
			setBounds(700, 300, 500, 400);
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); 
			setLocation((screenSize.width-getWidth())/2, (screenSize.height-getHeight())/2);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			String Route;
			if(e.getSource()==btn){
				Route=graph(a, b);
				route.setText(Route);
			}
			
		}
		@Override
		public void itemStateChanged(ItemEvent e) {
			if(e.getSource()==box1){
				start=box1.getSelectedItem().toString();
				if(start=="һ��")
				    a=0;
				else if(start=="����")
				    a=1;
				else if(start=="����")
				    a=2;
				else if(start=="����¥")
				    a=3;
				else if(start=="����¥")
				    a=4;
				else if(start=="��ͼ")
				    a=5;
				else if(start=="��ͼ")
				    a=6;
				else if(start=="��ѧԺ")
				    a=7;
				else if(start=="�ŵ�ѧԺ")
				    a=8;
				else if(start=="����ѧԺ")
				    a=9;
				else if(start=="ʳƷѧԺ")
				    a=10;
				else if(start=="��������")
				    a=11;
				else if(start=="������")
				    a=12;
				else if(start=="��ѧԺ")
				    a=13;
				else if(start=="��¥")
				    a=14;
			}
			if(e.getSource()==box2){
				end=box2.getSelectedItem().toString();
				if(end=="һ��")
				    b=0;
				else if(end=="����")
				    b=1;
				else if(end=="����")
				    b=2;
				else if(end=="����¥")
				    b=3;
				else if(end=="����¥")
				    b=4;
				else if(end=="��ͼ")
				    b=5;
				else if(end=="��ͼ")
				    b=6;
				else if(end=="��ѧԺ")
				    b=7;
				else if(end=="�ŵ�ѧԺ")
				    b=8;
				else if(end=="����ѧԺ")
				    b=9;
				else if(end=="ʳƷѧԺ")
				    b=10;
				else if(end=="��������")
				    b=11;
				else if(end=="������")
				    b=12;
				else if(end=="��ѧԺ")
				    b=13;
				else if(end=="��¥")
				    b=14;
			}
		}
		
	    public String graph(int a, int b)
	    {
	    	
	    	String[] vertices={Util.list.get(0).getName(),Util.list.get(1).getName(),
	    			Util.list.get(2).getName(),Util.list.get(3).getName(),Util.list.get(4).getName(),
	    			Util.list.get(5).getName(),Util.list.get(6).getName(),Util.list.get(7).getName(),
	    			Util.list.get(8).getName(),Util.list.get(9).getName(),Util.list.get(10).getName(),
	    			Util.list.get(11).getName(),Util.list.get(12).getName(),Util.list.get(13).getName(),
	    			Util.list.get(14).getName()};           
	        Triple[] edges={
	        			new Triple(0,1,Util.list1.get(0).getLongs()), new Triple(0,2,Util.list1.get(1).getLongs()), 
	        			new Triple(0,3,Util.list1.get(2).getLongs()),new Triple(0,4,Util.list1.get(3).getLongs()), 
	        			new Triple(0,5,Util.list1.get(4).getLongs()), new Triple(0,6,Util.list1.get(5).getLongs()), 
	        		 	new Triple(0,7,Util.list1.get(6).getLongs()),new Triple(0,8,Util.list1.get(7).getLongs()), 
	        		 	new Triple(0,9,Util.list1.get(8).getLongs()),new Triple(0,10,Util.list1.get(9).getLongs()),
	        			new Triple(1,0,Util.list1.get(0).getLongs()), new Triple(1,2,Util.list1.get(10).getLongs()),
	        			new Triple(1,6,Util.list1.get(11).getLongs()),new Triple(2,0,Util.list1.get(1).getLongs()), 
	        		 	new Triple(2,1,Util.list1.get(10).getLongs()), new Triple(2,3,Util.list1.get(12).getLongs()), 
	        		 	new Triple(3,0,Util.list1.get(2).getLongs()),new Triple(3,2,Util.list1.get(12).getLongs()),
	        		 	new Triple(3,4,Util.list1.get(13).getLongs()),
	        		 	new Triple(4,0,Util.list1.get(3).getLongs()),new Triple(4,3,Util.list1.get(13).getLongs()), 
	        		 	new Triple(4,5,Util.list1.get(14).getLongs()),
	        		 	new Triple(5,0,Util.list1.get(4).getLongs()),new Triple(5,4,Util.list1.get(14).getLongs()),
	        		 	new Triple(5,7,Util.list1.get(15).getLongs()),
	        		 	new Triple(6,0,Util.list1.get(5).getLongs()),new Triple(6,1,Util.list1.get(11).getLongs()), 
	        		 	new Triple(6,8,Util.list1.get(16).getLongs()),
	        		 	new Triple(7,0,Util.list1.get(6).getLongs()),new Triple(7,5,Util.list1.get(15).getLongs()),
	        		 	new Triple(7,10,Util.list1.get(17).getLongs()),
	        		 	new Triple(8,0,Util.list1.get(7).getLongs()),new Triple(8,6,Util.list1.get(16).getLongs()),
	        		 	new Triple(8,9,Util.list1.get(18).getLongs()),
	        		 	new Triple(9,0,Util.list1.get(8).getLongs()),new Triple(9,8,Util.list1.get(17).getLongs()), 
	        		 	new Triple(9,10,Util.list1.get(19).getLongs()),
	        		 	new Triple(10,0,Util.list1.get(9).getLongs()),new Triple(10,7,Util.list1.get(16).getLongs()),
	        		 	new Triple(10,9,Util.list1.get(19).getLongs()),
	        		 	new Triple(9,11,Util.list1.get(20).getLongs()),
	        		 	new Triple(9,12,Util.list1.get(21).getLongs()),
	        		 	new Triple(13,11,Util.list1.get(22).getLongs()),
	        		 	new Triple(12,14,Util.list1.get(23).getLongs()),
	        		 	new Triple(6,13,Util.list1.get(24).getLongs()),
	        		 	new Triple(7,14,Util.list1.get(25).getLongs()),
	        		 	new Triple(11,9,Util.list1.get(20).getLongs()),
	        		 	new Triple(12,9,Util.list1.get(21).getLongs()),
	        		 	new Triple(11,13,Util.list1.get(22).getLongs()),
	        		 	new Triple(14,12,Util.list1.get(23).getLongs()),
	        		 	new Triple(13,6,Util.list1.get(24).getLongs()),
	        		 	new Triple(14,7,Util.list1.get(25).getLongs()),
	        };
	        MatrixGraph<String> graph = new MatrixGraph<String>(vertices, edges);
	        return "�Ͻ�˹����:"+graph.dij(a, b)+"\n��������:"+graph.shortestPath(a,b);
	        //return graph.shortestPath(a,b);
	    }
}
