package Graph;

public class SinglyList<T>   
{
    public Node<T> head;                                 
    public SinglyList()                                    //���췽��������յ�����
    {
        this.head = new Node<T>();                         
    }
    
    public SinglyList(T[] values)
    {
        this();                                        
        Node<T> rear=this.head;                          
        for (int i=0; i<values.length; i++)               
            if (values[i]!=null)
            {
                rear.next=new Node<T>(values[i],null);    
                rear = rear.next;                         
            }
    }

    public T get(int i)                                    
    {
        Node<T> p=this.head.next;
        for (int j=0; p!=null && j<i; j++)                 
            p = p.next;
        return (i>=0 && p!=null) ? p.data : null;          
    }
    

    public void set(int i, T x)
    {  
        Node<T> p=this.head.next;
        for (int j=0; p!=null && j<i; j++)                 
            p = p.next;
        if (i>=0 && p!=null)
            p.data = x;                                    
    }     
    
    public String toString()
    {
        String str="";          
        for (Node<T> p=this.head.next;  p!=null;  p=p.next)
        {   str += p.data.toString();
            if (p.next!=null) 
                str += "---->";                               
        }
        return str+"";                                    
    }
 

    public Node<T> insert(int i, T x)
    {

        Node<T> front=this.head;                          
        for (int j=0;  front.next!=null && j<i;  j++)     
            front = front.next;
        front.next = new Node<T>(x, front.next);           
        return front.next;                                 
    }
    public Node<T> insert(T x)          
    {
        return insert(Integer.MAX_VALUE, x);
    }
      

}

