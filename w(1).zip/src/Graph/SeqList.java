package Graph;

public class SeqList<T> extends Object  
{
    protected Object[] element;                           
    protected int n;                                      

    //1. ���졢��ȡ
    public SeqList(int length)                           
    {
        this.element = new Object[length];                            
        this.n = 0;
    }
    public SeqList()                                       //����Ĭ�������Ŀձ������췽������
    {
        this(64);                                          //���ñ�����������ָ�������б��Ĺ��췽��
    }
    
    public SeqList(T[] values)                             //����˳�������values�����ṩԪ�أ��������пն���
    {
        this(values.length);                               //��������Ϊvalues.length�Ŀձ�               
        for (int i=0; i<values.length; i++)                
            this.element[i] = values[i];                   
        this.n = element.length;
    }
    
    public boolean isEmpty()                        
    {
        return this.n==0;
    }

    public int size()                                 
    {
        return this.n;
    }

    public T get(int i)                            
    {
        if (i>=0 && i<this.n)
            return (T)this.element[i]; 
        return null;
    }    

    public void set(int i, T x)
    {

        if (i>=0 && i<this.n)
            this.element[i] = x;
    }

    public String toString()
    {
        String str=this.getClass().getName()+"(";         
        if (this.n>0)
            str += this.element[0].toString();           
        for (int i=1; i<this.n; i++)
            str += ", "+this.element[i].toString();       
        return str+") ";                                   
    }
    
    public int insert(int i, T x)
    {

        if (i<0)       i=0;                                
        if (i>this.n)  i=this.n;                          
        Object[] source = this.element;                   
        if (this.n==element.length)                       
        {
            this.element = new Object[source.length*2];  
            for (int j=0; j<i; j++)                       
                this.element[j] = source[j];
        }
        for (int j=this.n-1; j>=i; j--)                  
            this.element[j+1] = source[j];
        this.element[i] = x;
        this.n++;
        return i;                                         
    }
    public int insert(T x)                              
    {
        return this.insert(this.n, x);                   
    }
}
