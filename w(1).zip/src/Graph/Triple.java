package Graph;


public class Triple
{
    int row, column, value;
    
    public Triple(int row, int column, int value)
    {

            this.row = row;
            this.column = column;
            this.value = value;

    }

    public String toString()                              
    {
        return "("+row+","+column+","+value+")";
    }

    public boolean removable()                           
    {
        return this.value==0;                              
    }

}
