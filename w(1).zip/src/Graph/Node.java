package Graph;

public class Node<T>                             
{
    public T data;                               //�����򣬴洢����Ԫ��
    public Node<T> next;                         //��ַ�����ú�̽��

    public Node(T data, Node<T> next)            
    {
        this.data = data;                        
        this.next = next;                        
    }
    public Node()
    {
        this(null, null);
    }
    public String toString()                   
    {
        return this.data.toString();
    }
}

